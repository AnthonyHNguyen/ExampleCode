from selenium import webdriver
from selenium.webdriver.chrome.service import Service
import json
import os
import shutil
import time
from pathlib import Path
from datetime import date

class HTMLtoPDF(object):

    def __init__(self, chamberSN):
        self.chamberSN = chamberSN

    def convertToPDF(self, htmlPath):
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument("download.default_directory=C:/Users/Public/Documents/National Instruments/LabVIEW Data/SWR-24030")

        settings = {
            "recentDestinations": [{
                "id": "Save as PDF",
                "origin": "local",
                "account": "",
            }],
            "selectedDestinationId": "Save as PDF",
            "version": 2,
            "isHeaderFooterEnabled": False,
            "marginsType": 1
        }

        prefs = {'printing.print_preview_sticky_settings.appState': json.dumps(settings)}
        #prefs = {'download.default_directory': "C:/Users/Public/Documents/National Instruments/LabVIEW Data/SWR-24030"}
        chrome_options.add_experimental_option('prefs', prefs)
        chrome_options.add_argument('--kiosk-printing')
        CHROMEDRIVER_PATH = '/usr/local/bin/chromedriver'
        #driver = webdriver.Chrome("C:\\Users\\anthonynguyen\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe", options=chrome_options)

        #s = Service("C:\\Users\\anthonynguyen\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe")
        s = Service("C:\\Users\\Public\\Documents\\National Instruments\\LabVIEW Config\\SWR-24030\\chromedriver.exe")
        driver = webdriver.Chrome(service=s, options=chrome_options)

        #Find html file
        #driver.get("C:/Users/anthonynguyen/Documents/Calibration/html/GOLD/CalibrationCertificate - Template_files/sheet001.htm")
        driver.get(htmlPath)
        

        driver.execute_script('window.print();')
        time.sleep(5)
        driver.quit()
        downloads_path = str(Path.home() / "Downloads")
        data_path = "C:\\Users\\Public\\Documents\\National Instruments\\LabVIEW Data\\SWR-24030"
        d = date.today()
        datestring = d.strftime("%Y%m%d")

        pdf_filename = "\\" + datestring + "-" + self.chamberSN + ".pdf"

        base=os.path.basename(htmlPath)
        os.path.splitext(base)
        filename = os.path.splitext(base)[0]
        #time.sleep(10)
        #os.rename(downloads_path + "\\" + filename + ".htm.pdf", data_path + pdf_filename)
        #time.sleep(10)
        return False
            
#hp = HTMLtoPDF("ec128")
#hp.convertToPDF("C:\\Users\\anthonynguyen\\Documents\\GitHub\\SWR-24030\\html\\GOLD\\CalibrationCertificate - Template_files\\1234567.htm")




