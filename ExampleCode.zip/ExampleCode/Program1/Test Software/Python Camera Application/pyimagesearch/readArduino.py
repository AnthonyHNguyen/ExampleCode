import time
import serial

ser = serial.Serial('COM13',19200)

while True:
    unicode = ser.readline()
    value = (unicode.decode('utf-8'))
    floatVal = float(value)
    print(floatVal)
    if floatVal > 3:
       print("true")
    time.sleep(0.5)